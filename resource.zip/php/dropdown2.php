
<style>
        /* Basic styling for the dropdown1 */
        .dropdown1 {
            position: relative;
            display: inline-block;
        }
.dropdown1 a {
    font-size: 20;
    display: block;
    padding: 10px;  
    text-align: center;
    color: rgba(215, 162, 4, 0.98);
    text-decoration: none; 
    transition: opacity 2.5s ease;
}

.dropdown1 a:hover {
    background-color: #a59b0c;

    border-radius: 5px;
    color: rgb(68, 155, 231); 
}

        .dropdown1-content {
            display: none;
            position: absolute;
            width: 400px;
            background-color: rgb(224, 224, 224);
            border-radius: 10px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown1-content a{
            width:400px;
        }


        .dropdown1:hover .dropdown1-content {
            display: block;
        }
    </style>


<div class="dropdown1">
    <a href="http://localhost/project2/about.php" class="dropbtn1">ABOUT</a>
    <div class="dropdown1-content">
        <a href="http://localhost/project2/about.php">Our Story & Mission</a>
        <a href="http://localhost/project2/faq.php">Frequently Asked Questions (FAQ):</a>
    </div>
</div>


