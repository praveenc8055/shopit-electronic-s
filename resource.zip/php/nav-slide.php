<nav class="slide-nav1" >
    <div class="inline1">
             <a href="http://localhost/project2/index.php">HOME </a>
            
             <?php include "php/dropdown.php"?>
             
             <a href="http://localhost/project2/shop.php">SHOP  </a>

             <?php include "php/dropdown2.php"?>
             
             <a href="http://localhost/project2/contact.php">CONTACT  </a> 
    </div>
    <div>
            <?php include "php/search.php"?>   
    </div>   
    
</nav> 
<style>

.slide-nav1{
            margin-top:20px; 
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            border: 0px solid rgb(204, 163, 0); /* Light border */
            border-radius:10px;
            padding:10px;
}
.inline1{
display: flex;

}


.slide-nav1 a {
    font-size: 20;
    display: block;
    width :auto ; 
    padding: 20px;  
    text-align: center;
    color: rgba(215, 162, 4, 0.98);
    text-decoration: none; 
    transition: opacity 3.5s ease;
}
.slide-nav1 a:hover {
    background-color:rgba(165, 155, 12, 0);
    border-radius: 5px;
    color: rgb(68, 155, 231);
    text-decoration: underline;  
}
    </style>