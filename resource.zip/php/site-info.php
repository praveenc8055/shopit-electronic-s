
    
<div class="background-section">
    <div class="overlay10"></div>
    <div class="content-container">
        <br><br><br>
    <h1 class="heading-with-background"><br>   
                SHOPIT PRODUCTS
                <img src="bgi/logo.1.png" alt="Background Image1" class="background-image">
                </h1>
                <div class="container15">
        <div class="column1"><img src="pic/si1.png" alt="Image 1"><br><br><h2>Mobiles</h2></div>
        <div class="column1"><img src="pic/si2.png" alt="Image 2"><br><br><h2>Laptop</h2></div>
        <div class="column1"><img src="pic/si3.png" alt="Image 3"><br><br><h2>Ear Phones</h2></div>
        <div class="column1"><img src="pic/si4.png" alt="Image 4"><br><br><h2>Charger</h2></div>
        <div class="column1"><img src="pic/si5.jpeg" alt="Image 4"><br><br><h2>Spare Parts</h2></div>
    </div>
    <div class="contant">
    <div class="container16">
        <ul>
            <li><h2><ion-icon name="checkmark-circle"></ion-icon>  Samsung </h2></li>
            <li><h2><ion-icon name="checkmark-circle"></ion-icon>  POCO C61</h2></li>
            <li><h2><ion-icon name="checkmark-circle"></ion-icon>  OnePlus</h2></li>
        </ul>    
        <ul>
            <li><h2><ion-icon name="checkmark-circle"></ion-icon>  Lenovo </h2></li>
            <li><h2><ion-icon name="checkmark-circle"></ion-icon>  Dell Inspiron</h2></li>
            <li><h2><ion-icon name="checkmark-circle"></ion-icon>  ASUS </h2></li>
        </ul>

        <ul>
            <li><h2><ion-icon name="checkmark-circle"></ion-icon>  boAt </h2></li>
            <li><h2><ion-icon name="checkmark-circle"></ion-icon>  Ambrane</h2></li>
            <li><h2><ion-icon name="checkmark-circle"></ion-icon>  JBL </h2></li>
        </ul>
        <ul>
            <li><h2><ion-icon name="checkmark-circle"></ion-icon>  Mi Xiaomi</h2></li>
            <li><h2><ion-icon name="checkmark-circle"></ion-icon>  ABRALE</h2></li>
            <li><h2><ion-icon name="checkmark-circle"></ion-icon>  pTron</h2></li>
        </ul>
        <ul>
            <li><h2><ion-icon name="checkmark-circle"></ion-icon>  SanDisk</h2></li>
            <li><h2><ion-icon name="checkmark-circle"></ion-icon>  FRONTECH</h2></li>
            <li><h2><ion-icon name="checkmark-circle"></ion-icon>  Motherboard</h2></li>
        </ul>
        </div><br><br>
        <h1><a href="" class="button9"> SHOP PRODUCTS</a></h1>
        
</div>
    </div>

</div>
<style>
        .container16 {
            display: flex; /* Enables flexbox layout */
            justify-content: space-between; /* Distributes space between items */
          
        }
        .contant ul {
            list-style-type: none; /* Removes default bullet points */
            padding:0px; /* Removes default padding */
            margin: 0; /* Removes default margin */
            
            width: 250px; /* Sets width to ensure four lists fit in a row */
        }
        .contant li {
            text-align: left;
            padding: 20px; /* Adds padding to list items */
        }
        
.container15 {
    border-bottom: 5px solid rgb(251, 252, 251);
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    margin: 0 auto; /* Center the container */
}

.column1 {
    margin: 60px; /* Space between columns */
}

.column1 img {
    border-radius: 20px;
    width: 150px; /* Make images responsive */
    height: 150px; /* Maintain aspect ratio */
}

    
.background-section {
    position: relative;
    height: 1000px; /* Full viewport height */
    background-image: url('pic/l.3.png'); /* Replace with your image URL */
    background-size: cover; /* Cover the entire section */
    background-position: center; /* Center the image */
}

.overlay10 {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(201, 92, 24, 0.7); /* Black overlay with 50% transparency */
}

.content-container {
    position: relative;
    z-index: 1; /* Ensure content is above the overlay */
    display: flex;
    flex-direction: column;
    align-items: center;
    height: 100%; /* Full height of the section */
    color: white; /* Text color */
    text-align: center; /* Center text */
}
.button9 {
    display: inline-block; /* Makes the anchor behave like a block element */
    padding: 10px 20px; /* Adds space inside the button */
    background-color:rgb(124, 179, 21); /* Initial background color */
    color: white; /* Text color */
    text-decoration: none; /* Removes underline from the link */
    border-radius: 5px; /* Rounds the corners */
    transition: background-color 0.3s; /* Smooth transition for hover effect */
}

.button9:hover {
    background-color:rgb(15, 215, 241); /* Changes background color on hover */
}

    </style>