
<div class="search-container">
    <input type="text" id="search-input" placeholder="Search...">
    <button id="search-button">
        <i class="fa fa-search"><ion-icon name="search"></ion-icon></i>
    </button>
</div>

<style>
.search-container {
    background-color: transparent;
    display: flex;
    align-items: right;
    border: 1px solid rgb(201, 219, 13);
    border-radius: 5px;
    padding: 10px;
    width: 250px;
}

#search-input {
    background-color: transparent;
    border: none;
    outline: none;
    flex: 1;
    padding: 10px;
}
.search-input::placeholder {
    color: rgb(201, 219, 13);
    opacity: 1; 
}

#search-button {
    justify-content: center;
    background-color: transparent;
    color:rgba(197, 185, 23, 0.84);
    border: none;
    cursor: pointer;
    padding: 1px;
}

#search-button i {
    font-size:35;
    color:rgba(197, 185, 23, 0.84);
}

</style>