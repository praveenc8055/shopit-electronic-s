<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="description" content="We have a wide collection of electronics, phones, books, and games">
    <meta name="keywords" content="phones, books, games, electronics">
    <link rel="stylesheet" href="css/style3.css">
    <link rel="stylesheet" href="css/style2.css">
    <link rel="stylesheet" href="css/style1.css">
    <link rel="stylesheet" href="css/style4.css">
    <link rel="stylesheet" href="css/style5.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <title>SHOPIT</title>
</head>