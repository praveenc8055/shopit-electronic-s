<header>
<img src="pic/logo n1.png" style="max-width: 250px; height: 130px;">
</header>
