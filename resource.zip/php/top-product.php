<div name="main">
            <div class="container1">
                <div class="container1-1">
                <div class="container2">
                 <h1 class="heading-with-background"><br>   
                SHOPIT: Shop smarter, not harder.
                <img src="bgi/logo.1.png" alt="Background Image" class="background-image1">
                </h1>
                    </div>
                <br><br><br>
                
                <h2>
                    Welcome to ShopIt!  We're thrilled to have you explore our wide selection
                of products.  Whether you're searching for everyday essentials or that special
                something you've been eyeing, we've curated a diverse collection to meet
                your needs.  Browse our categories, utilize our convenient search function, 
                and discover the perfect items at competitive prices.  Happy shopping! 
                </h2>
                </div>
                <div class="container1-2" >
                <a class="img1" href="http://localhost/project2/index.php">
                    <img src="bgi/bg5.jpg" >
                    <div class="overlay5"></div>
            </a>
                
            </div>
            </div> 
            <?php include "php/sample.php"?> 
<style>
img1{
    position: relative;
    display: inline-block;
    width: 50%;
    height: 600px    }
.overlay5 {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(255, 254, 254, 0.54); /* Semi-transparent black */
    opacity: 0;
}

.img1:hover .overlay5 {
    opacity: 1; /* Show overlay on hover */
}
.background-image1 {  
    position: absolute;
    top: -120px;
    left: 90px;
    z-index: -1;
    opacity: 1;
    bottom: 50;
    right: 40px;
}
    </style>
