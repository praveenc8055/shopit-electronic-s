<?php

$servername="localhost";
$username="root";
$password="";
$dbname="user";


$conn=mysqli_connect($servername,$username,$password,$dbname);
if($conn)
{
    echo '<script>alert("connection ok")</script>';
}
else
{
    echo '<script>alert("connection failed")</script>';
}
//getting values
if($_POST['register'])
{
$name1       =$_POST['name1'];
$name2        =$_POST['name2'];
$userid     =$_POST['userid'];
$email      =$_POST['email'];
$password   =$_POST['password'];
$cpassword  =$_POST['cpassword'];
$number     =$_POST['number'];


$data="SELECT * FROM `users` WHERE `email` != '$email' AND `userid` != '$userid'";

$run=mysqli_query($conn,$data);
$count=mysqli_num_rows($run);



if($name1 != "" && $name2 != ""  && $userid != "" && $email != "" && $password != "" && $cpassword != ""  && $number != "")
{ 
    if($count>=0){   
        if($password == $cpassword )
        {
         
            $result="INSERT INTO `users` (`name1`, `name2`, `userid`, `email`, `password`, `cpassword`, `number`)
             VALUES (  '$name1', '$name2', '$userid', '$email', '$password',  '$cpassword', '$number')" ;
            echo '<script>alert("registration successfully")</script>';
     } 
     
    else{
        echo '<script>alert("password not matched")</script>';
     }
     
          
    }
    else{
        echo '<script>alert("email or userid is already existence")</script>';
    }

}
else{
    echo '<script>alert("fill all details above given")</script>';
    
}
$execute=mysqli_query($conn,$result);
}

if($execute)
{
    echo '<script>alert("executed")</script>';
    header("location:http://localhost/project2/index.php");
}
else{
    echo'<script>alert("not executed")</script>';
}

?>