<footer>
  <style>
  
  footer {
    background-color: rgb(74, 73, 73);
    padding: 20px 0;
    margin-top: 80px;
    bottom: 0;
    }  
.container20 {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            margin-top: 80px;
            padding: 20px;
            color:white;
            
            
        }
        .container20 a{
        padding:10px;
        font-size: 22;
        text-decoration: none;
        color: white;
        }
        .column1 {
            flex: 1;
            margin: 10px;
            min-width: 200px;
            align: center;
        }        

        .column {
            flex: 1;
            margin: 10px;
            min-width: 200px;
        }
        .column ul {
            list-style-type: none;
            padding: 0;
        }
        .input-container {
            position: relative;
        }
        .input-container input {
            width: 100%;
            padding: 10px 40px 10px 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .input-container .icon {
            color: black;
            position: absolute;
            right: 50px;
            top: 16%;
            transform: translateY(-50%);
            pointer-events: none;
            font-size: 24px;
        }
        .row-list {
            display: flex;
            list-style-type: none;
            padding: 0;
        }
        .row-list li {
            margin-right: 5px;
        }
    </style>

    
<div class="container20">
    <div class="column" >
        <div class="column1">
    <img src="bgi/logo.5.png"  height="250px" width="250px">

        <ul class="row-list">
            <?php
                $items = ['
    <a href="#"> <ion-icon name="logo-facebook"></ion-icon></ion-icon></a>', 
        '<a href="#">  <ion-icon name="mail"></ion-icon></a>', 
        '<a href="#">  <ion-icon name="logo-youtube"></ion-icon></a>', 
        '<a href="#">  <ion-icon name="logo-whatsapp"></ion-icon></a>'];
                foreach ($items as $item) {
                    echo "<li>$item</li>";
                }
            ?>
        </ul>
        
    </div>
    </div>
    <div class="column" >
        <h1>Policy Pages</h1>
        <ul>
            <li><a href="terms-of-service.php">Terms of Service</a><br></li><br>
            <li><a href="privacy-policy.php">Privacy Policy</a><br></li><br>
            <li><a href="shipping-policy.php">Shopping Policy</a><br></li><br>
            <li><a href="refund-policy.php">Refund Policy</a><br></li><br>
            <li><a href="subscription-policy.php">Return Policy</a><br></li><br>
        </ul>
    </div>
    <div class="column">
    <h1>Stay in touch!</h1>
        <ul>
            <li>address: <br><br><br><br></li>
            <li>Email: cpraveenraju876@gmail.com<br><br></li>
            <li>Contact: +91 9361094639</li>
        </ul>
    </div>
    <div class="column input-container" style="padding:40px;">
        <input type="text" placeholder="Enter text here...">
        <span class="icon"><ion-icon name="paper-plane-sharp"></ion-icon></h2></span>
    </div>
</div>
<hr color="white" padding="5px" width="90%" align="center">
<div class="footend">
    
            <div align="left">
            <h2 style="margin: 22px;">This website is created for sample</h2>
            </div>
            <div align="right">
            <img src="pic/l-l-1.png" style="max-width: 90px; height: 70px; border-radius: 10px;" >
            <img src="pic/l.l.2.png" style="max-width: 90px; height: 70px; border-radius: 10px;" >
            <img src="pic/l.l.3.png" style="max-width: 90px; height: 70px; border-radius: 10px;" >
            <img src="pic/e.l.1.png" style="max-width: 90px; height: 70px; border-radius: 10px;" >
            <img src="pic/m.l.1.png" style="max-width: 90px; height: 70px; border-radius: 10px;"   >
            <img src="pic/m.l.2.png" style="max-width: 90px; height: 70px; border-radius: 10px;"  >

            </div>
            
</div>

</footer>
<style>
    .footend{
        display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            margin-right: 80px;
            margin-left: 80px;
            color:  white;

    }
    </style>
