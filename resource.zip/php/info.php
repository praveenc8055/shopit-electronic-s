<div class="container22">
        <div class="column3">
            
        <div class="info01">
                <img src="pic/l.1.png" width="250px" height= "250px">
                <p>Lenovo IdeaPad 1 Intel Core Celeron</p>
                <ul >
                    <li>Display: 39.62 cms (15.6 inches), HD</li>
                    <li>Memory: 8GB DDR4 RAM, 512GB SSD ROM</li>
                    <li>Processor: Intel Celeron N4020</li>
                    <li>OS: Windows 11 Home</li>
                    <li>Graphics: Intel UHD Graphics</li>
                    <li>Included Software: MS Office Home And Student 2021</li>
                    <li>Material: PC-ABS Composite</li>
                    <li>Warranty: 1 Year Onsite</li>
                </ul>
                </div>      
                <div class="info01">
                <img src="pic/c.4.png" width="250px" height= "250px">
                <p>@ptron charger 2.4 amp</p>
                </div>    
                <div class="info01">
                <img src="pic/e.1.png" width="250px" height= "250px">
                <p>boAt Airdopes 141 ANC TWS</p>
                <ul>
                    <li>Category: Wireless Earbuds</li>
                    <li>Bluetooth Version: v5.3</li>
                    <li>Music Playtime: Up to 42 Hours</li>
                    <li>Stand By: 80 Hours</li>
                    <li>Charging Time: 1.5 Hours</li>
                    <li>Operating Range: 10m</li>
                     <li>Battery: 400mAh (Case) / 35mAh x 2 (Earbuds)</li>
                </ul>
                </div>  
                <div class="info01">
                <img src="pic/M.2.png" width="250px" height= "250px">
                <p>POCO C61 Diamond Dust Black</p>
                </div>       
        </div>
        <div class="column3">
        <div class="info01">
            <img src="pic/M.1.png" width="250px" height= "250px">
                <p>Samsung Galaxy S24 Ultra 5G</p>

                <ul>
                    <li>RAM: 12 GB</li>
                    <li>ROM: 512 GB</li>
                    <li>Display: 17.27 cm (6.8 inch) Quad HD+</li>
                    <li>Rear Camera: 200MP + 50MP + 12MP + 10MP</li>
                    <li>Front Camera: 12MP</li>
                    <li>Battery: 5000 mAh</li>
                    <li>Processor: Snapdragon 8 Gen 3</li>
                </ul>              </div>
               
               
                <div class="info01">
                <img src="pic/e.2.png" width="250px" height= "250px">
                <p>boAt Bass Heads 225 in-Ear Wired Headphones</p>
                </div>
                <div class="info01">
                <img src="pic/s.4.jpg" width="250px" height= "250px">
                <p>sandisk pen-drive c type</p>
                </div>                
                <div class="info01">
                <img src="pic/s.5.jpg" width="250px" height= "250px">
                <p>samsung m35 5g backpouch</p>
                </div>
        </div>
        <div class="column3">
            
        <div class="info01">
                <img src="pic/l.3.png" width="250px" height= "250px">
                <p> Dell Inspiron 3535, AMD Ryzen 3</p>
                </div>
                <div class="info01">
                <img src="pic/M.3.png" width="250px" height= "250px">
                <p>Nothing Phone (2a) 5G</p>
                </div>
               
               
                <div class="info01">
                <img src="pic/e.3.png" width="250px" height= "250px">
                <p>JBL Wave Beam in-Ear Wireless Earbuds (TWS)</p>
                </div>
                <div class="info01">
                <img src="pic/c.3.png" width="250px" height= "250px">
                <p>supervooc charger</p>
                </div>

        </div>
        
    </div>
</div>
<style>

.container22 {
    display: flex;
    flex-wrap: wrap;
    padding: 10px;
    
}
.container22 p{
    text-align: center;
    font-size: 24    
}
.container22 img{
    width: 500px;
    height: 450px;
    display: block;
    justify-items: center;

    
}
.info01{
    height:800px;
}

.column3 {
    flex: 1 1 25%; /* Default to four columns */
    padding: 10px;
    box-sizing: border-box; /* Include padding in width calculation */
    background-color: #f0f0f0;
    margin: 5px; /* Space between columns */
    text-align: left;

}

/* Media query for responsive design */
@media (max-width: 1000px) {
    .column3 {
        flex: 1 1 33.33%; /* Change to three columns */
    }
}

@media (max-width: 700px) {
    .column3 {
        flex: 1 1 100%; /* Change to one column */
    }
}
</style>