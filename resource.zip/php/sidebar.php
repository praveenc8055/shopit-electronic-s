<div class="left">
    <div class="section title"><h2>Category</h2></div>
   
                        <a>mobiles</a>
                        <a>laptops</a>
                        <a>chargers</a>
                        <a>earphones</a>
                        <a>spareparts</a>
    
</div> 