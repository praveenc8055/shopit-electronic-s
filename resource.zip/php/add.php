<?php
error_reporting(0);
$servername="localhost";
$username="root";
$password="";
$dbname="products";


$conn=mysqli_connect($servername,$username,$password,$dbname);
if($conn)
{
    echo '<script>alert("connection ok")</script>';
}
else
{
    echo '<script>alert("connection failed")</script>';
}
//getting values
if($_POST['additem'])
{
$name       =$_POST['name'];
$pic       =$_POST['pic'];
$itemid     =$_POST['itemid'];
$info      =$_POST['info'];
$price       =$_POST['price'];



$data="SELECT * FROM `product` WHERE `itemid` != '$itemid'";

$run=mysqli_query($conn,$data);
$count=mysqli_num_rows($run);



if($name != "" && $pic != "" && $itemid != "" && $info != "" && 
$price != "" )
{ 
    if($count>=0){
       
            $result="INSERT INTO `product` ( `name`, `itemid`, `pic`, `info`, `price`) 
           VALUES (  '$name', '$itemid', '$pic', '$info', '$price')";
            echo '<script>alert("product added successfully")</script>';

     
          
    }
    else{
        echo '<script>alert("product is already existence")</script>';
    }

}
else{
    echo '<script>alert("fill all details above given")</script>';
    
}
$execute=mysqli_query($conn,$result);
}

if($execute)
{
    echo '<script>alert("executed")</script>';
    header("location: http://localhost/project/index.php");
}
else{
    echo'<script>alert("not executed")</script>';
}

?>
