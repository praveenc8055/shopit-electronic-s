
<nav class="navbar">
        <ul class="left-items">
        <li><a href="#"> <ion-icon name="logo-facebook"></ion-icon></ion-icon></a>  
		<li><a href="#">  <ion-icon name="mail"></ion-icon></a>  
		<li><a href="#">  <ion-icon name="logo-youtube"></ion-icon></a> 
        <li><a href="#">  <ion-icon name="logo-whatsapp"></ion-icon></a></li>
        </ul>
        <ul class="right-items">

			
		<li><a href="login.php" style="font-size: 20;">  <ion-icon name="person-sharp" style="font-size:25;"></ion-icon>   LOGIN</a>  
		<li class="highlight"><a href="http://localhost/project2/cart.php"> <ion-icon name="cart-outline">  </ion-icon> 5</a>  

        </ul>
    </nav>
	<style>


.navbar {
    background-color:rgb(220, 133, 11);;
    display: flex;
    justify-content: space-between;
    align-items :center;
    color: black;
    
    
}
.navbar i
    {
    margin-top: 10px;
    display: block;
    height: 100%;
    width: 90%
}


.left-items, .right-items {
    list-style-type: none;
    margin: 0;
    
    padding: 0px;
    
    display: flex;
}


 .right-items li {
    font-size: 25;
    min-width: 100px;
    align-items : right;
    justify-content: center;
    text-align: center;
    padding: 10px;
}
.left-items li {
    font-size: 25;
    width: 50px;
    justify-content: center;
    align-items: center ;
    text-align: center;
    padding: 10px;
}

.left-items a, .right-items a {
    text-decoration: none;
    color: black;
}

.left-items a:hover, .right-items a:hover {
    color: white;
}

.highlight {
    background-color : rgba(10, 172, 216, 0.79);
}
.highlight: hover {
    background-color : rgb(255, 255, 255);
}
	</style>
