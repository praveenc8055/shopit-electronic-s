<style>
        .container {
            width: 100%;
    height: auto;
    position: relative;
    overflow: hidden;

    transition: height 0.3s ease;
}
        
        .container img {
            width: 100%;
            height: auto;
            display: block;
            
        }
        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: center;
            align-items: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        .container:hover {
            width: 500px;
            height: 550px;
        }
        .container:hover .overlay {
            opacity: 1;
        }
        .overlay a {
            font-style:bold;
            font-size:20;
            position: absolute;
            top: 50%;
            left: 50%;
            border-radius:5px;
            transform: translate(-50%, -50%); /* Center the anchor tag */
            background-color: transparent; /* Transparent background */
            border: 5px solid white; /* White border */
            padding: 10px 20px; /* Padding for the anchor tag */
            text-decoration: none; /* Remove underline */
            color: white; /* Text color */
            transition: background-color 0.3s ease; /* Smooth transition for background */
        }

        .overlay a:hover {
            background-color: rgba(255, 255, 255, 0.3); /* Change background on hover */
        }
        .container11 {
            display: flex; /* Enables flexbox layout */
            justify-content: space-around; /* Distributes space between items */
            margin-bottom:50px;
            margin-top:50px;
            height: 700px;
        }

.box1 {
    background-color:rgb(253, 255, 253); /* Green background */
    border-radius: 20px;
    padding: 0px;
    flex: 1 1 25%; /* Allows boxes to grow equally */
    margin: 10px; /* Adds space between boxes */
    text-align: center; /* Centers text */
}
/* Media query for responsive design */
@media (max-width: 1000px) {
    .box1 {
        flex: 1 1 33.33%; /* Change to three columns */
    }
}

@media (max-width: 700px) {
    .box1 {
        flex: 1 1 100%; /* Change to one column */
    }
}

    </style>
    <div class="container2">
    <h2 class="heading-with-background"><br>   
                Laptop Collection
                <img src="bgi/logo.1.png" alt="Background Image" class="background-image">
                </h2>
    </div>

    <div class="container11">
        <div class="box1">    
            <div class="container">
            <img src="pic/l.1.png" width= "500px" height= "450px">
            <div class="overlay">
            <a href="#">Quick View</a>
            </div>
            
            </div>
                <h2>Lenovo IdeaPad 1
                Intel Core Celeron</h2>
        </div>
        <div class="box1">      
            <div class="container">
            <img src="pic/l.2.png" width= "500px" height= "450px">
            <div class="overlay">
            <a href="#">Quick View</a>
            </div>
            
            </div>
            <h2>ASUS Vivobook Go 14
            Intel Celeron Dual Core N4500</h2>
        </div>
        <div class="box1">    <div class="container">
    <img src="pic/l.3.png" width= "500px" height= "450px">
        <div class="overlay">
            <a href="#">Quick View</a>
        </div>
            
    </div>
    <h2>Dell Inspiron 3535 AMD Ryzen 3</h2>
    </div>
    </div>
    
    <div class="container2">
    <h2 class="heading-with-background"><br>   
                Mobile Collection
                <img src="bgi/logo.1.png" alt="Background Image" class="background-image">
                </h2>
    </div>    
    <div class="container11">
        <div class="box1">    
            <div class="container">
            <img src="pic/M.1.png"" width= "500px" height= "450px">
            <div class="overlay">
            <a href="#">Quick View</a>
            </div>
            
            </div>
                <h2>Samsung Galaxy S24 Ultra 5G</h2>
        </div>
        <div class="box1">      
            <div class="container">
            <img src="pic/M.2.png"" width= "500px" height= "450px">
            <div class="overlay">
            <a href="#">Quick View</a>
            </div>
            
            </div>
            <h2>POCO C61 Diamond Dust Black</h2>
        </div>
        <div class="box1">    
            <div class="container">
    <img src="pic/M.3.png"" width= "500px" height= "450px">
        <div class="overlay">
            <a href="#">Quick View</a>
        </div>
            
    </div>
    <h2>Nothing Phone (2a) 5G</h2></div>
    </div>
    <div class="container2">
    <h2 class="heading-with-background"><br>   
                Spare-Part Collection
                <img src="bgi/logo.1.png" alt="Background Image" class="background-image">
                </h2>
    </div>
    <div class="container11">
        <div class="box1">    
            <div class="container">
            <img src="pic/s.1.jpg" width= "500px" height= "450px">
            <div class="overlay">
            <a href="#">Quick View</a>
            </div>
            
            </div>
                <h2>MSI B450M-A PRO MAX II Motherboard, Micro-ATX, AM4 DDR4</h2>
        </div>
        <div class="box1">      
            <div class="container">
            <img src="pic/s.2.jpg" width= "500px" height= "450px">
            <div class="overlay">
            <a href="#">Quick View</a>
            </div>
            
            </div>
            <h2>TP-Link USB Bluetooth Adapter for PC, 5.3 Bluetooth</h2>
        </div>
        <div class="box1">    <div class="container">
    <img src="pic/s.3.jpg" width= "500px" height= "450px">
        <div class="overlay">
            <a href="#">Quick View</a>
        </div>
            
    </div>
    <h2>FRONTECH Wired Gaming Keyboard</h2>
    </div>
    </div>
    