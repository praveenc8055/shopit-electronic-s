
    <style>
        /* Basic styling for the dropdown */
        .dropdown {
            position: relative;
            display: inline-block;
        }
.dropdown a {
    font-size: 20;
    display: block;
    padding: 10px;  
    text-align: center;
    color: rgba(215, 162, 4, 0.98);
    text-decoration: none; 
    transition: opacity 2.5s ease;
}

.dropdown a:hover {
    background-color: #a59b0c;
    border-radius: 5px;
    color: rgb(68, 155, 231); 
}

        .dropdown-content {
            display: none;
            position: absolute;
            background-color:rgb(224, 224, 224);
            border-radius: 10px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }



        .dropdown:hover .dropdown-content {
            display: block;
        }
    </style>


<div class="dropdown">
    <a href="#" class="dropbtn">PRODUCT</a>
    <div class="dropdown-content">
        <a href="http://localhost/project2/mobile.php">MOBILE</a>
        <a href="http://localhost/project2/laptop.php">LAPTOP</a>
        <a href="http://localhost/project2/earphone.php">EARPONE</a>
        <a href="http://localhost/project2/others.php">OTHERS</a>
    </div>
</div>


