
<?php

$servername="localhost";
$username="root";
$password="";
$dbname="feedback";


$conn=mysqli_connect($servername,$username,$password,$dbname);
if($conn)
{
    echo '<script>alert("connection ok")</script>';
}
else
{
    echo '<script>alert("connection failed")</script>';
}
//getting values
if($_POST['feedback'])
{
$name       =$_POST['name'];
$message     =$_POST['message'];




$data="SELECT * FROM `feedbacks` ";

$run=mysqli_query($conn,$data);
$count=mysqli_num_rows($run);



if($name != "" && $message != ""  )
{ 
    if($count>=0){
       
            $result="INSERT INTO `feedbacks` ( `name`,`message`) 
           VALUES (  '$name', '$message')";
            echo '<script>alert("contact added successfully")</script>';

     
          
    }
    else{
        echo '<script>alert("product is already existence")</script>';
    }

}
else{
    echo '<script>alert("fill all details above given")</script>';
    
}
$execute=mysqli_query($conn,$result);
}

if($execute)
{
    echo '<script>alert("executed")</script>';
    header("location: http://localhost/project2/faq.php");
}
else{
    echo'<script>alert("not executed")</script>';
}

?>


