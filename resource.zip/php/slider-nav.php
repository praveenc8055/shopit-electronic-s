<nav class="slide-nav" >
    <div class="overlay1-1">
             <a href="http://localhost/project2/index.php">HOME </a>
            
             <?php include "php/dropdown.php"?>
             
             <a href="http://localhost/project2/shop.php">SHOP  </a>
             
             <?php include "php/dropdown2.php"?>

             <a href="http://localhost/project2/contact.php">CONTACT  </a> 

            </div>
    <div class="overlay1-2" >
            <?php include "php/search.php"?>   
    </div>   
    
</nav> 
<script >
    document.querySelectorAll('.selection-option').forEach(option => {
    option.addEventListener('click', function(event) {
        event.preventDefault();
        const selectedValue = this.getAttribute('data-value');
        console.log('Selected:', selectedValue);
        // Additional logic can be added here
    });
});
</script><style>
.selection-container {
        
    display: flex;
    gap: 10px;
}

.selection-option {
    padding: 10px 20px;
    background-color: #007BFF;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    transition: background-color 3.5s;
}

.selection-option:hover {
    background-color: #0056b3;
}
    </style>