<div class="slider">

    <div class="slides">
        
        <div class="slide active">
            <img src="bgi/bg11.jpg" alt="Slide 1" >
            
            
                <div class="overlay1" >
                <?php include "php/slider-nav.php"?>
                <div class="n1">
                        <h1 style="color:#ffffff; font-size: 70px; ">Welcome to Our Site</h1>
                        <a class="button1" href="" >KNOW MORE</a><br>
                        <a class="button2" href="" >CONTINUE SHOPPING</a>    
                    </div>
                    </div>
            
        </div>
        <div class="slide">
            <img src="bgi/bg13.png"alt="Slide 2">
            
            
                    <div class="overlay1"  >
                    <?php include "php/slider-nav.php"?>
                        <div class="n2">
                        <h1 style="color:#ffffff; font-size: 70px;">We will privide<br> Best quality</h1>
                        <a class="button1" href="" >QULITY STANDARD</a>
                        </div>
                        
                    </div>
           
        </div>
        <div class="slide">
            <img src="bgi/bg6.jpg" alt="Slide 3">
            
            
                    <div class="overlay1"  >
                    
                    <?php include "php/slider-nav.php"?>
                    <div class="n3">
                        <h1 style="color:#ffffff; font-size: 70px;">Easy to SINGUP &<br>Easy to experience of our site </h1>
                        <a class="button1" href="">SINGUP</a>
                    </div>
                </div>
            
        </div>
    </div>
    <button class="prev" onclick="changeSlide(-1)" style="font-size: 30; border-radius:50px; "><ion-icon name="arrow-back-outline"  ></ion-icon></button>
    <button class="next" onclick="changeSlide(1)" style="font-size: 30; border-radius:50px; "><ion-icon name="arrow-forward-outline"></ion-icon></button>
</div>
<style>
    </style>
  <script>
  let currentSlide = 0;

function showSlide(index) {
    const slides = document.querySelectorAll('.slide');
    if (index >= slides.length) {
        currentSlide = 0;
    } else if (index < 0) {
        currentSlide = slides.length - 1;
    } else {
        currentSlide = index;
    }
    const offset = -currentSlide * 100;
    document.querySelector('.slides').style.transform = `translateX(${offset}%)`;
}

function changeSlide(direction) {
    showSlide(currentSlide + direction);
}


setInterval(() => {
    changeSlide(1);
}, 30000);
  
    </script>
    