<div class="star-rating">
        <input type="radio" name="rating" id="star1" value="5">
        <label for="star1" class="star"></label>
        <input type="radio" name="rating" id="star2" value="4">
        <label for="star2" class="star"></label>
        <input type="radio" name="rating" id="star3" value="3">
        <label for="star3" class="star"></label>
        <input type="radio" name="rating" id="star4" value="2">
        <label for="star4" class="star"></label>
        <input type="radio" name="rating" id="star5" value="1">
        <label for="star5" class="star"></label>
    </div>
    <script >const stars = document.querySelectorAll('.star-rating input');

stars.forEach(star => {
    star.addEventListener('change', () => {
        const rating = star.value;
        console.log(`You rated this ${rating} star(s)!`);
    });
});
</script>
    <style>
    .star-rating {
    direction: rtl;
    display: flex;
    justify-content: center;
}

.star {
    font-size: 30px;
    color: lightgray;
    cursor: pointer;
}

input[type="radio"] {
    display: none;
}

input[type="radio"]:checked ~ .star {
    color: gold;
}

.star:hover,
.star:hover ~ .star {
    color: gold;
}

        </style>
